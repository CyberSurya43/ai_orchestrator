#!/usr/bin/env python3
"""Entry point for running AI Orchestrator as a module or standalone."""

if __name__ == "__main__":
    from ai_orchestrator.cli import main
    main()
